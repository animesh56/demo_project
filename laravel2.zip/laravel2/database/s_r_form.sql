-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2022 at 01:11 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `s_r_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `p_list`
--

CREATE TABLE `p_list` (
  `id` int(11) NOT NULL,
  `p_id` varchar(110) DEFAULT NULL,
  `p_name` varchar(110) DEFAULT NULL,
  `p_price` varchar(110) DEFAULT NULL,
  `p_desc` varchar(220) NOT NULL,
  `img` mediumtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `p_list`
--

INSERT INTO `p_list` (`id`, `p_id`, `p_name`, `p_price`, `p_desc`, `img`, `created_at`, `status`) VALUES
(1, '1', '2', '3', '4', '1670969271531401102.jfif~1670969271113354859.png', '2022-12-13 22:07:52', 0),
(2, '11', '22', '33', '44', '1670969292196092968.jfif~1670969292384710973.png', '2022-12-13 22:08:12', 0),
(5, 'q2', 'e3', 'r4', 'r5', '16709736101037875593.png~16709736102051008606.jfif', '2022-12-13 23:20:10', 0),
(11, 'yppopo', 'p', 's', 'r', '1670973774162063168.png~1670973774505222185.jfif', '2022-12-13 23:22:54', 0),
(12, 'yppopo', 'p', 's', 'r', '1670973775159627619.png~16709737751038147840.jfif', '2022-12-13 23:22:56', 0),
(13, 'e2', 'q2', '5t', '67', '16710128491922473309.png', '2022-12-13 23:24:51', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `p_list`
--
ALTER TABLE `p_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `p_list`
--
ALTER TABLE `p_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
