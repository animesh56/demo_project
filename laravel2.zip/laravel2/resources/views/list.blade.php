<!-- print_r($list); -->
<?php //echo'<pre>';print_r($list); ;?>


	<!DOCTYPE html>
<html lang="en">
<head>
  <!-- <title>Bootstrap Card</title> -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body> 
 




<hr><br>
<div class="container">
<input type="checkbox" id="s_check" name="vehicle1" value="Bike" onclick="show_list()" >
<label for="s_check"> Show all tasks</label><br>
<script>
	function show_list(){
	 var x = document.getElementById("s_list");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }


  var y = document.getElementById("all_list");
  if (y.style.display === "none") {
    y.style.display = "block";
  } else {
    y.style.display = "none";
  }

}
	</script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                	
<style>
	input[type="checkbox"]{
  width: 20px; /*Desired width*/
  height: 20px; /*Desired height*/
}
</style>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <h2>List of tasks <?php //app()->version();?></h2>
  <div class="card">
<!-- 
  	  --><div class="form-group">

  	 	<div class="row">
  	 		<div class="col-md-10 ">
  	 			<table style="width:100%"><td style="width:10px">
      	<i class='fa fa-user-circle-o' style='font-size:36px;float:right'>:</i></td>
      	<td >
      	<input type="test" class="form-control" id="task" placeholder="Enter Task Name" name="task" style="width:100%;float:right">
      <script>
      	$("#task").on('keyup', function (e) {
    if (e.key === 'Enter' || e.keyCode === 13) {
add_task() ;
    	 }
});
      </script>

      </td></table>
      </div>
      <div class="col-md-2">          
        <button type="button" class="btn btn-block btn-primary" onclick="add_task()">Add</button>
      </div>  </div>
    <!-- </div> -->


    <div class="." style="display:" id="s_list">
<table class="tb">

	<?php $i=1;
$list = DB::select("SELECT * FROM list where status=0 order by id desc");
	foreach($list as $l){?>
	<tr>
		<td width="10px" style="width:10px"><?=$i;?></td>
		<td width="20px" style="width:20px"><input type="checkbox"  onclick="m_completed('<?=$l->id;?>')" 
			<?php if($l->status == 1){ echo 'checked';}?>></td>
		<td><?=$l->name;?></td>
		<td><?php 
	// $rpg = $this->lib_model->Select('employer', 'log_in_time', array('id' => $r->created_by));
                $dateNow = date("Y/m/d H:i:s");
                $last_login = $l->created_at ;
                $ts1 = strtotime($dateNow);
                $ts2 = strtotime($last_login);     
                $seconds_diff = $ts1 - $ts2;
                $min = ($seconds_diff/60) ;
                // echo $min;
                if($min <> 20){
					$datetime1 = new DateTime($dateNow);//start time
                    $datetime2 = new DateTime($last_login);//end time
                    $interval = $datetime1->diff($datetime2);

						if($min < 61){
							echo 'updated '.$interval->format('%i minutes') .' Ago';
						}
                    else if(  ($min > 61) && ($min < 1441) )
					{
						// echo $interval->format('%H hours');
						echo 'updated '.$interval->format('%H hours') .' Ago';
					}
					else if($min > 1441){
						// echo $interval->format('%d days');
						echo 'updated '.$interval->format('%d days') .' Ago';
					}
                    // echo $interval->format('%Y years %m months %d days %H hours %i minutes %s seconds');
                    
                }else{
                    echo (int)$min .' Ago';
                } 
                ?></td>

                <td><a onclick="return confirm('Are u sure to delete this task ?');" href="<?php echo url('t_delete') .'/'. $l->id; ?>" ><i class="fa fa-trash-o" style="font-size:36px"></i></a>
                </td>

		<?php $i++; } ?>
			</tr></table>




			 <script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>
<input type="hidden" name="_token" value="{{ csrf_token() }}" id="csrf">
 <script>
            function m_completed(id){
                var csrf = document.getElementById("csrf").value ;
                // var f_name = document.getElementById("f_name").value ;  
                  
                
                if(id !== ''){
                    // document.getElementById("submitBuyForm").submit();
                    var dataString = '&_token='+csrf+'&id='+id ;
    // alert(dataString) ;
    $.ajax({
        type: 'POST',
        url: '<?php echo url('change_ajax'); ?>',
        data:dataString,        
        success: function (response) {
            var data = JSON.parse(response);
            // console.log(data.html_job_applied) ;
            // var t_msg = 0 ;
            // var data11 = data.data11 ;
            // console.log(data.data11) ;
            var status = data.status ;
           
                alert('Task '+status+' Successfully .');
                $('#s_check').prop('checked', false);
                document.getElementById("all_list").style.display = "none";
                document.getElementById("s_list").style.display = "block";
                $("#s_list").load(location.href + " #s_list");
                // location.reload();
                      
        }
    });
                }else{
                    alert('Something went wrong  .')
                    location.reload();
                }
            }
            </script>



            <script>
            function add_task(){
                var csrf = document.getElementById("csrf").value ;
                var t_name = document.getElementById("task").value ; 

                    // document.getElementById("submitBuyForm").submit();
                    var dataString = '&_token='+csrf+'&t_name='+t_name ;
    // alert(dataString) ;
    $.ajax({
        type: 'POST',
        url: '<?php echo url('add_task_ajax'); ?>',
        data:dataString,        
        success: function (response) {
            var data = JSON.parse(response);
            // console.log(data.html_job_applied) ;
            // var t_msg = 0 ;
            // var data11 = data.data11 ;
            // console.log(data.data11) ;
            var status = data.status ;
           	if(status =='added'){
                alert('Task '+status+' Successfully .');
                document.getElementById("task").value = '' ;
                $('#s_check').prop('checked', false);
                document.getElementById("all_list").style.display = "none";
                document.getElementById("s_list").style.display = "block";
                $("#s_list").load(location.href + " #s_list");
            }
            else{
            	alert('Duplicate Task .');
            	$('#s_check').prop('checked', false);
            	document.getElementById("all_list").style.display = "none";
            	document.getElementById("s_list").style.display = "block";
            	document.getElementById("task").value = '' ;

                // location.reload();
            }
                      
        }
    });
                
            }
            </script>



			<style>
.tb {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

.tb.tb  td, .tb th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

.tb tr:nth-child(even) {
  background-color: #dddddd;
}
</style>

    </div>








    <!--  -->


<div class="." style="display:none" id="all_list">
<table class="tb">

	<?php $i=1;
$list = DB::select("SELECT * FROM list order by id desc");
	foreach($list as $l){?>
	<tr>
		<td width="10px" style="width:10px"><?=$i;?></td>
		<td width="20px" style="width:20px"><input type="checkbox"  onclick="m_completed('<?=$l->id;?>')" 
			<?php if($l->status == 1){ echo 'checked';}?>></td>
		<td><?=$l->name;?></td>
		<td><?php 
	// $rpg = $this->lib_model->Select('employer', 'log_in_time', array('id' => $r->created_by));
                $dateNow = date("Y/m/d H:i:s");
                $last_login = $l->created_at ;
                $ts1 = strtotime($dateNow);
                $ts2 = strtotime($last_login);     
                $seconds_diff = $ts1 - $ts2;
                $min = ($seconds_diff/60) ;
                // echo $min;
                if($min <> 20){
					$datetime1 = new DateTime($dateNow);//start time
                    $datetime2 = new DateTime($last_login);//end time
                    $interval = $datetime1->diff($datetime2);

						if($min < 61){
							echo 'updated '.$interval->format('%i minutes') .' Ago';
						}
                    else if(  ($min > 61) && ($min < 1441) )
					{
						// echo $interval->format('%H hours');
						echo 'updated '.$interval->format('%H hours') .' Ago';
					}
					else if($min > 1441){
						// echo $interval->format('%d days');
						echo 'updated '.$interval->format('%d days') .' Ago';
					}
                    // echo $interval->format('%Y years %m months %d days %H hours %i minutes %s seconds');
                    
                }else{
                    echo (int)$min .' Ago';
                } 
                ?></td>

                <td><a onclick="return confirm('Are u sure to delete this task ?');" href="<?php echo url('t_delete') .'/'. $l->id; ?>" ><i class="fa fa-trash-o" style="font-size:36px"></i></a>
                </td>

		<?php $i++; } ?>
			</tr></table>




    </div>









  </div>
</div>

</body>
</html>
