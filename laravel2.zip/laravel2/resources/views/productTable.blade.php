


<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

<script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>


<script src="https://cdn.datatables.net/1.13.1/js/dataTables.bootstrap5.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">


                              
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap5.min.css">



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
                              
<br>

<h3 style="text-decoration:underline;text-align: center" > Product List</h3>

<!-- <a href="<?php echo url('addProduct'); ?>" class="btn btn-primary" target="_blank" data-toggle="modal" data-target="#myModal">Add Product</a> -->
<a class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal" 
onclick="$('#application_form').trigger('reset');$('#modalTiltle').text('Add Product');$('#divEdit').html('');document.getElementById('btn_save11').style.display = '';document.getElementById('btn_edit11').style.display = 'none';"style="margin-left:20%">Add Product</a>

<hr>
<div class="." style="display:" id="s_list">



 <table id="example" class="table table-bordered table-striped" style="width:100%">
        <thead>
            <tr>
                <th>S.no</th>
                <th>Product Id</th>
                 <th>Product Name</th>
                <th>Product Price</th>
                <th>Product Description</th>
                <th >Product Image</th>
                <th>Action</th>
            </tr>
        </thead>
 
        <tfoot>

 <!-- id, product_name, product_price, product_desccription, product_image -->

            <tr>
            	<th>S.no</th>
                <th>Product Id</th>
                <th>Product Name</th>
                <th>Product Price</th>
                <th>Product Description</th>
                <th >Product Image</th>
                <th>Action</th>
            </tr>
        </tfoot>
 
        <tbody>
        	<?php $i=1;
$list = DB::select("SELECT * FROM p_list where status=0 order by id desc");
	foreach($list as $l){?>
            <tr>
                <td><?=$i;?></td>
                <td><?=$l->p_id;?></td>
                <td><?=$l->p_name;?></td>
                <td><?=$l->p_price;?></td>
                <td><?=$l->p_desc;?></td>
                <td>
  <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal_img1122"
  onclick="showImages('<?=$l->img;?>')"> view Images</button>

                </td>

                 <td>
 <button class="btn btn-info"  data-bs-toggle="modal" data-bs-target="#myModal"
 onclick="editPage('<?=$l->id;?>' ,'<?=$l->p_id;?>' , '<?=$l->p_name;?>' , '<?=$l->p_price;?>' ,'<?=$l->p_desc;?>' ,'<?=$l->img;?>')" > Edit</button>
               <button class="btn btn-danger" onclick="pDelete('<?=$l->id;?>')" > Delete</button>


                </td>
            </tr>
           <?php $i++; } ?>

        </tbody>
    </table>

    </div>

<script>
	function pDelete(id){

		var conf = confirm("Are you sure You want to delete this item");
		if (conf == true) {
			var csrf = $('#_token').val(); 
		var dataString = '&_token='+csrf+'&productId='+id ;
        
    $.ajax({
        type: 'POST',
        url: '<?php echo url('delete_product_ajax'); ?>',
        data:dataString,        
        success: function (response) {
            var data = JSON.parse(response);
            if(data.status == 'deleted'){ 
			$("#s_list").load(location.href + " #s_list");
            $('#example').DataTable();
              alert('Img Deleted Successfully .')


            }else{
                alert('SOMETHING WENT WRONG PLEASE TRY AGAIN .');
                location.reload();
            }
            
        }
    }); 
}

	}
</script>

    <script>
    	$(document).ready(function () {
    $('#example').DataTable();
});
</script>
<style type="text/css">
	
table th:nth-child(3), td:nth-child(3) {
  display: none;
}



</style>

<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title" id="modalTiltle">Add Product</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       
<script type="text/javascript">
	function editPage(id ,p_id , p_name , p_price ,p_desc ,img){
        $('#application_form').trigger('reset');
		$('#p_id').val(p_id) ;
		$('#p_name').val(p_name) ;
		$('#p_price').val(p_price) ;
		$('#p_desc').val(p_desc) ;

$("#modalTiltle").text("Edit Product");
document.getElementById("btn_save11").style.display = "none";
document.getElementById("btn_edit11").style.display = "";

$("#divEdit").html("");
$(".gallery").html("");
$($.parseHTML('<input type="hidden" value="'+id+'" name="row_id">')).appendTo('#divEdit');

		var myArray = img.split("~");
var url = '<?php echo url('storage') . '/'; ?>';
		 myArray.forEach(function (item) {

let r = (Math.random() + 1).toString(36).substring(7);

$($.parseHTML('<div id="'+r+'" class="'+r+'" class="col-md-2" ><img style="width:30%;margin:10px;border:1px solid black" src="'+url+item+'"><input type="hidden" value="'+item+'" name="p_old_img[]"> <span onclick="removeDiv11(`'+r+'`)" style="color:" class="btn btn-danger">DELETE</span></div>')).appendTo('#divEdit');

		 	});

	}

	function removeDiv11(id){
        document.getElementById(id).remove();		
	}
</script>

<form  action="<?=url('add_product_ajax'); ?>" enctype="multipart/form-data" method="POST" id="application_form" >
     <!-- <input type="hidden" name="_token" value="xtQapusSjgf5XVUxjCOudedeH93a8hEqyfaNh8ChEaKt">  -->

     <input type="hidden" name="_token"  id="_token" value="{{ csrf_token() }}">
     
<!-- id, product_name, product_price, product_desccription, product_image -->
    <div class="" id="req" style="color:red;text-align:center"></div>

    <div class='row form-group'>
        <div class='col-lg-6'>
            <label class='control-label' style="font-weight:bold">Product ID*</label>
            <input type='text' class='form-control' id='p_id' name='p_id' required>
        </div>
         <div class='col-lg-6'>
            <label class='control-label'  style="font-weight:bold">Product Name*</label>
            <input type='text' class='form-control' id='p_name'  name='p_name' required>
        </div>
         <div class='col-lg-6'>
            <label class='control-label'  style="font-weight:bold">Product Price*</label>
            <input type='text' class='form-control' id='p_price' name='p_price' required>
        </div>
         <div class='col-lg-6'>
            <label class='control-label'  style="font-weight:bold">Product Description*</label>
            <input type='text' class='form-control' id='p_desc' name='p_desc' required>
        </div>
         <div class='col-lg-12'>
            <label class='control-label'  style="font-weight:bold">Product Image*</label>
            <input type='file' class='form-control' id='p_img' name="p_img[]" onchange="add_img()" multiple required="required">
            <!-- <input type="file" multiple id="gallery-photo-add"> -->
<div class="gallery" class='col-lg-12'></div>
<div id="divEdit" style="display:" class='col-lg-12'></div>
        </div>
       
     </div>
     <hr>

     <div class="row">
        <div style="text-align:center;margin-top:10px" class='col-lg-6' >
     <button type="button"  class="btn btn-primary text-uppercase" 
     onclick="uploadSkuImg('application_form')" id="btn_save11">Submit <i class='fa fa-check text-white'></i></button>

     <button type="button"  class="btn btn-primary text-uppercase" 
     onclick="preventForm22('application_form')" id="btn_edit11">Submit edit <i class='fa fa-check text-white'></i></button>

      <!-- <button class="btn btn-primary text-uppercase"  >Submit <i class='fa fa-check text-white'></i></button> -->

        </div>

        <div style="text-align:center;margin-top:10px" class='col-lg-6' >
    
<button type="button" class="btn btn-danger" data-bs-dismiss="modal" id="close_save">Close</button>
     

        </div>
</div>



         
        
</form>



      </div>

      <!-- Modal footer -->
<!--       <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div> -->

    </div>
  </div>
</div>

 <!-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script> -->
<!-- <input type="hidden" name="_token" value="{{ csrf_token() }}" id="csrf"> -->

<!-- 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script> -->
<script>



function uploadSkuImg(id){

let fileType = $('#p_img')[0].files[0].type;
let fileSize = $('#p_img')[0].files[0].size;
let name = $('#p_img')[0].files[0].name;

if(fileSize > 10000000000000){
alert('File Size Exceeded .');
return 0;
}

preventForm22(id) ;

}

function preventForm22(id) {
  
$(document).ready(function() {
$('#application_form').submit(function (e) {
e.preventDefault();

var url = '<?php echo url('add_product_ajax'); ?>';
$.ajax({
url: url  ,
type: 'post',
data: new FormData(this),
processData: false,
contentType: false,
cache: false,
async: false,
success: function (result){
result = JSON.parse(result);
if(result.status == 'added'){
$("#req").html("");
alert('File Uploaded Successfully .');
$("#s_list").load(location.href + " #s_list");
	document.getElementById("close_save").click();
	$('#application_form').trigger("reset");
$(".gallery").html("");
$('#example').DataTable();


}else if(result.status == 'required'){
// alert('PLEASE FILL ALL FIELDS TO SUBMIT .');
$("#req").html("PLEASE FILL ALL FIELDS TO SUBMIT .");
}
else{
alert('Something Went Wrong .');
location.reload();
}
}

});
});
$('#application_form').submit();  


});


} 



</script>

<!-- 
//   $("#other1").load(location.href + " #other1");

//   location.reload();
// $("#imgTr1111").load(location.href+" #imgTr1111>*","");
// $("#td"+id).load(location.href + " #td"+id);


//    $("#home111").load(location.href+" #home111>*",""); -->


<script>

       	$(function() {
    // Multiple images preview in browser
    var imagesPreview = function(input, placeToInsertImagePreview) {

        if (input.files) {
            var filesAmount = input.files.length;

            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();

                reader.onload = function(event) {

     $("#"+placeToInsertImagePreview).html("");

let r = (Math.random() + 1).toString(36).substring(7);

$($.parseHTML('<span class="col-md-2" id="'+r+'" style="color:red;verticle-align:;margin:5px" onclick="deleteDiv('+r+')"><img style="width:70px" src="'+event.target.result+'"> </span>')).appendTo(placeToInsertImagePreview);


                }

                reader.readAsDataURL(input.files[i]);
            }
        }

    };

    $('#p_img').on('change', function() {
        imagesPreview(this, 'div.gallery');
    });
});

       	function add_img(){

       	}
       </script>


<script>
	function showImages(img){
		$("#divImgs").html("");

		var myArray = img.split("~");
var url = '<?php echo url('storage') . '/'; ?>';
		 myArray.forEach(function (item) {

$($.parseHTML('<img style="max-width:45%;margin:10px;border:1px solid black" src="'+url+item+'">')).appendTo('#divImgs');
// $("#divImgs").html('<img style="width:100%" src="'+url+item+'"><br>');

		 	});
	}

	
</script>


<div class="modal" id="myModal_img1122">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Product Images</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" id="divImgs">
        
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>



<div class="modal" id="myModal_edit">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Product Images</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" id="divEdit">
        
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
