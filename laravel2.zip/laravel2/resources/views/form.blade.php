

@if(Session::has('success'))
<p class="alert {{ Session::get('alert-info') }}">{{ Session::get('success') }}</p>
@endif

<form  action="<?=url('save_form'); ?>" enctype="multipart/form-data" id='application_form' method="POST">
     <!-- <input type="hidden" name="_token" value="xtQapusSjgf5XVUxjCOudedeH93a8hEqyfaNh8ChEaKt">  -->

     <input type="text" name="_token" value="{{ csrf_token() }}">

    
    <div class='row form-group'>
        <div class='col-lg-6'>
            <label class='control-label'>First name*</label>
            <input type='text' class='form-control' name='f_name' value="">
        </div>
        <div class='col-lg-6'>
            <label class='control-label' >Last name*</label>
            <input type='text' class='form-control' name='l_name' value="">
        </div>
     </div>
     

     <button class="btn btn-primary text-uppercase">Submit <i class='fa fa-check text-white'></i></button>

</form>
