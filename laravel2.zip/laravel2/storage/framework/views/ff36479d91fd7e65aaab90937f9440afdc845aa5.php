

<?php if(Session::has('success')): ?>
<p class="alert <?php echo e(Session::get('alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
<?php endif; ?>

<form  action="<?=url('save_form_img'); ?>" enctype="multipart/form-data" id='application_form' method="POST">

	<input type="text" name="_token" value="<?php echo e(csrf_token()); ?>" id="csrf">

	 <div class='row form-group'>
        <div class='col-lg-6'>
            <label class='control-label'>img*</label>
            <input type='file' class='form-control' name='file' id='file11' value=""  >
        </div>
    </div>

        <button class="btn btn-primary text-uppercase">Submit <i class='fa fa-check text-white'></i></button>

        	</form>

        	

<?php /**PATH C:\xampp\htdocs\laravel\laravel2\resources\views/imgUpload.blade.php ENDPATH**/ ?>