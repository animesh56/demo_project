

<?php if(Session::has('success')): ?>
<p class="alert <?php echo e(Session::get('alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
<?php endif; ?>

<form  action="<?=url('save_form'); ?>" enctype="multipart/form-data" id='application_form' method="POST">
     <!-- <input type="hidden" name="_token" value="xtQapusSjgf5XVUxjCOudedeH93a8hEqyfaNh8ChEaKt">  -->

     <input type="text" name="_token" value="<?php echo e(csrf_token()); ?>">

    
    <div class='row form-group'>
        <div class='col-lg-6'>
            <label class='control-label'>First name*</label>
            <input type='text' class='form-control' name='f_name' value="">
        </div>
        <div class='col-lg-6'>
            <label class='control-label' >Last name*</label>
            <input type='text' class='form-control' name='l_name' value="">
        </div>
     </div>
     

     <button class="btn btn-primary text-uppercase">Submit <i class='fa fa-check text-white'></i></button>

</form>
<?php /**PATH C:\xampp\htdocs\laravel\laravel2\resources\views/form.blade.php ENDPATH**/ ?>