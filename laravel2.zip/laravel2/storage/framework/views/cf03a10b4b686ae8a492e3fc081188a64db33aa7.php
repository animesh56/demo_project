



<?php if(Session::has('success')): ?>
<p class="alert <?php echo e(Session::get('alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
<?php endif; ?>

<form  action="<?=url('save_form'); ?>" enctype="multipart/form-data" id='application_form' method="POST">
     <!-- <input type="hidden" name="_token" value="xtQapusSjgf5XVUxjCOudedeH93a8hEqyfaNh8ChEaKt">  -->

     <input type="text" name="_token" value="<?php echo e(csrf_token()); ?>" id="csrf">

    
    <div class='row form-group'>
        <div class='col-lg-6'>
            <label class='control-label'>First name*</label>
            <input type='text' class='form-control' name='f_name' id='f_name' value=""  >
        </div>
        <div class='col-lg-6'>
            <label class='control-label' >Last name*</label>
            <input type='text' class='form-control' name='l_name' id='l_name' value="">
        </div>
     </div>

      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
     
     <p class="btn btn-primary" onclick="submitForm()">Submit Ajax </p>
     <!-- <button class="btn btn-primary text-uppercase">Submit <i class='fa fa-check text-white'></i></button> -->

</form>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>

 <script>
            function submitForm(){
                var csrf = document.getElementById("csrf").value ;
                var f_name = document.getElementById("f_name").value ;  
                var l_name = document.getElementById("l_name").value ;  
                
                if(l_name !== ''){
                    // document.getElementById("submitBuyForm").submit();
                    var dataString = '&_token='+csrf+'&f_name='+f_name+'&l_name='+l_name ;
    alert(dataString) ;
    $.ajax({
        type: 'POST',
        url: '<?php echo url('save_form_ajax'); ?>',
        data:dataString,        
        success: function (response) {
            var data = JSON.parse(response);
            // console.log(data.html_job_applied) ;
            var t_msg = 0 ;
            var data11 = data.data11 ;
            console.log(data.data11) ;
            var status = data.status ;
            if(status == 'success')  { 
                alert('Password Changed Successfully .');
                // location.reload();
            }
           
        }
    });
                }else{
                    alert('New password and confirm password are not matching .')
                    // return false ;
                }
            }
            </script><?php /**PATH C:\xampp\htdocs\laravel\laravel2\resources\views/ajaxForm.blade.php ENDPATH**/ ?>