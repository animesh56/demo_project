

<?php if(Session::has('success')): ?>
<p class="alert <?php echo e(Session::get('alert-info')); ?>"><?php echo e(Session::get('success')); ?></p>
<?php endif; ?>

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>



<h3 style="text-decoration:underline;text-align: center" > Add Product</h3>

<a href="<?php echo url('productList'); ?>" class="btn btn-primary" target="_blank">Product List</a>
<hr>


<form  action="<?=url('save_form'); ?>" enctype="multipart/form-data" id='application_form' method="POST">
     <!-- <input type="hidden" name="_token" value="xtQapusSjgf5XVUxjCOudedeH93a8hEqyfaNh8ChEaKt">  -->

     <input type="text" name="_token" value="<?php echo e(csrf_token()); ?>">
<!-- id, product_name, product_price, product_desccription, product_image -->
    
    <div class='row form-group'>
        <div class='col-lg-6'>
            <label class='control-label'>Product ID*</label>
            <input type='text' class='form-control' name='f_name' value="">
        </div>
         <div class='col-lg-6'>
            <label class='control-label'>Product Name*</label>
            <input type='text' class='form-control' name='f_name' value="">
        </div>
         <div class='col-lg-6'>
            <label class='control-label'>Product Price*</label>
            <input type='text' class='form-control' name='f_name' value="">
        </div>
         <div class='col-lg-6'>
            <label class='control-label'>Product Description*</label>
            <input type='text' class='form-control' name='f_name' value="">
        </div>
         <div class='col-lg-6'>
            <label class='control-label'>Product Image*</label>
            <input type='text' class='form-control' name='f_name' value="">
        </div>
       
     </div>
     
        <div style="text-align:center;" >
     <button class="btn btn-primary text-uppercase" >Submit <i class='fa fa-check text-white'></i></button>
        </div>
        
</form>
<?php /**PATH C:\xampp\htdocs\laravel2\resources\views/addproduct.blade.php ENDPATH**/ ?>