-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2022 at 05:49 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `s_r_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `list`
--

CREATE TABLE `list` (
  `id` int(11) NOT NULL,
  `name` varchar(11111) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `list`
--

INSERT INTO `list` (`id`, `name`, `status`, `created_at`) VALUES
(2, 'test2', 0, '2022-11-23 19:54:17'),
(3, 'test3', 0, '2022-11-23 19:54:26'),
(5, 'TEST5', 0, '2022-11-23 19:02:14'),
(6, 'TEST6', 0, '2022-11-23 19:54:26'),
(8, 'TEST8', 0, '2022-11-23 18:32:21'),
(9, 'task9', 1, '2022-11-23 19:54:43'),
(10, 'task11', 1, '2022-11-23 20:17:40'),
(11, '11', 1, '2022-11-23 20:07:45'),
(12, '12', 1, '2022-11-23 20:07:41'),
(14, '14', 0, '2022-11-23 20:08:08'),
(15, '15', 0, '2022-11-23 20:07:51'),
(17, 't16', 1, '2022-11-23 20:17:36'),
(19, 't17', 1, '2022-11-23 20:17:26');

-- --------------------------------------------------------

--
-- Table structure for table `s_r_form`
--

CREATE TABLE `s_r_form` (
  `id` int(11) NOT NULL,
  `s_type` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_id` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_name` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_url` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_desc` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_userBase` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_n_name` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_n_desig` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_n_email` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_n_mobile` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_n_address` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_r_time_typ` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_r_other` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_escName_1` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_escEmail_1` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_mobile_1` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_desig_1` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_escName_2` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_escEmail_2` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_mobile_2` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_desig_2` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_escName_3` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_escEmail_3` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_mobile_3` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_desig_3` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_escName_4` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_escEmail_4` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_mobile_4` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_mobile_11` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_desig_4` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file1` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file2` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file3` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file4` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file5` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file6` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file7` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file8` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file9` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file10` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_ex_file11` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_avg_cl` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_workingDays` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `s_p_workingHours` varchar(56) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `s_r_form`
--

INSERT INTO `s_r_form` (`id`, `s_type`, `s_p_id`, `s_name`, `s_url`, `s_desc`, `s_userBase`, `s_n_name`, `s_n_desig`, `s_n_email`, `s_n_mobile`, `s_n_address`, `s_r_time_typ`, `s_r_other`, `s_p_escName_1`, `s_p_escEmail_1`, `s_p_mobile_1`, `s_p_desig_1`, `s_p_escName_2`, `s_p_escEmail_2`, `s_p_mobile_2`, `s_p_desig_2`, `s_p_escName_3`, `s_p_escEmail_3`, `s_p_mobile_3`, `s_p_desig_3`, `s_p_escName_4`, `s_p_escEmail_4`, `s_p_mobile_4`, `s_p_mobile_11`, `s_p_desig_4`, `s_ex_file`, `s_ex_file1`, `s_ex_file2`, `s_ex_file3`, `s_ex_file4`, `s_ex_file5`, `s_ex_file6`, `s_ex_file7`, `s_ex_file8`, `s_ex_file9`, `s_ex_file10`, `s_ex_file11`, `s_p_avg_cl`, `s_p_workingDays`, `s_p_workingHours`, `status`, `created_on`, `created_by`) VALUES
(6, 'Central', '09871212322', 'ab', 'cd', 'ef', 'Central', 'gh', 'ij', 'abcd@gmail.com', 'mn', 'op', 'Response', 'qrst', 'uv', 'wxabcd@gmail.com', 'yz', 'ab12', '23ew', '45tyabcd@gmail.com', '98uj', '09ol', '34rfg', '45tghabcd@gmail.com', 'jko90', '9867jh', '123dgj', '86hghjabcd@gmail.com', '889ihghj', NULL, '23rsdgbjh', 'FEcNPwas1636970703_wet.jpg', NULL, 'Fpeyfhxb1636970703_mahadev.jpg', 'z9CVlNgE1636970703_mahakal.jpg', '7XpMmSw21636970703_wq.jpg', 'VGdUszWQ1636970703_qq.jpg', 'ETopsrzf1636970703_love.jpg', 'ZiRjpbxS1636970703_pp.jpg', 'pyD4Ttgq1636970703_ooppppppppp.jpg', 'VpgsvJLC1636970703_', 'vBIJteyh1636970703_mahadev.jpg', 'NZ5nRfMv1636970703_mahakal.jpg', 'qw244r', '23', '123efhd', 0, '2021-11-15 15:35:03', 11),
(7, 'NIC', '1234567890', 'testing Name', 'http://besthelp.in/mahadeva/Task/fillForm', 'this is a testing for description', 'Central', 'abhay singh', 'kanpur', 'abhay@gmail.com', '1234567890', 'testing address', 'Update', 'testing others specify', 'name 1', 'email1@gm.com', '12345678790', 'testing des 2', 'name 2 ', 'email2@gm2.com', '12323456787', 'testing des 2', 'name 3', 'email3@gm2.com', '12323456785', 'testing des 3', 'name 4', 'email4@gm2.com', '123234567870', NULL, 'testing des 4', 'oViYnQmU1636971536_jw.jpg', NULL, 'xeWIUnKb1636971536_mahadev.jpg', 'tPTA7zce1636971536_mahakal.jpg', '0qRCpt8z1636971536_qqqq.jpg', 'cmeUP4yo1636971536_ko.jpg', 'U1X2o8iS1636971536_jw.jpg', 'Sf1suXNG1636971536_ooppppppppp.jpg', '8HsCmwgE1636971536_mahadev.jpg', 'DbE6phMq1636971536_qqqq.jpg', 'hGXBvmUN1636971536_qq.jpg', 'SCrPuMKD1636971536_wet.jpg', 'teting avg no', '15 ', '15-11-2021', 0, '2021-11-15 15:48:56', 11),
(8, 'NIC', 'PPT1', 'qweqwe', 'ewqe', 'eqwe', 'Central', 'we', 'ewqe', 'deepa@tetrain.com', 'qewe', 'eqw', 'Update', '132', '312', 'deepa@tetrain.com', '', '', '312', 'deepa@tetrain.com', '', '', 'ede', 'deepa@tetrain.com', '', '', 'e', 'deepa@tetrain.com', '', NULL, '', 'fzGhZeTu1636979756_', NULL, 'lC2XIvwi1636979756_', 'uxahzYHO1636979756_', 'C8NJLmip1636979756_', 'IeQU1ZKM1636979756_', 'Fz7rRWZO1636979756_', 'drkxVn0H1636979756_', 'qaSrtQiG1636979756_', 'WDCYpfKV1636979756_', 'mHcTizgE1636979756_', 'mzuChAbQ1636979756_', '', '', '', 0, '2021-11-15 18:05:56', 11),
(9, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', 'VB5Uciqf1636979802_', NULL, 'uArWmYeJ1636979802_', 'w7JFHknQ1636979802_', '1yMi5VaU1636979802_', 'gw5s3zLS1636979802_', 'qv9YeR2N1636979802_', '1jKfxe6T1636979802_', 'h9oUpsJb1636979802_', 'oeBPyhKD1636979802_', 'px7BP2He1636979802_', 'H0vOjPGl1636979802_', '', '', '', 0, '2021-11-15 18:06:42', 11),
(10, 'NIC', 'rwe', 'wer', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', 'HtqI8mOr1636979808_', NULL, 'odryb9DL1636979808_', 'WeEwZOyR1636979808_', 'Oa5xUj891636979808_', 'hj6t70wm1636979808_', 'riF4vpfu1636979808_', 'z8P0IUgC1636979808_', 'je328BOm1636979808_', 'aCFgJXcn1636979808_', 'IC9feZMX1636979808_', 'KMTx4AIS1636979808_', '', '', '', 0, '2021-11-15 18:06:48', 11),
(11, 'NIC', '312', '321', 'weewrr.iii', 'ffwrf', 'Public', 'rf', 'r', 'rf@tetrain.com', '132312314', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', NULL, '', 'Ll9Jd05E1636979990_', NULL, '8VFnkfmh1636979990_', 'zfeis8J71636979990_', '520NUC8n1636979990_', '4jU3EQoq1636979990_', 'ZMnvu7hc1636979990_', 'qE7kJhUL1636979990_', 'edYMGx7b1636979990_', 'E9iQjK5R1636979990_', '8QkmCHs01636979990_', 'mlBcP40x1636979990_', '', '', '', 0, '2021-11-15 18:09:50', 11),
(12, '1222', '12112121', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, '1222', '12112121', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, '1222', '12112121', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, '1222', '12112121', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, '343443', '343443', '343443', '343443', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `list`
--
ALTER TABLE `list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `s_r_form`
--
ALTER TABLE `s_r_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `list`
--
ALTER TABLE `list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `s_r_form`
--
ALTER TABLE `s_r_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
