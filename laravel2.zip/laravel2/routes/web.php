<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\testing;
use App\Http\Controllers\new_test;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[testing::class,'productList']);


// ======================================================

Route::get('/productList',[testing::class,'productList']);


Route::get('/addProduct',[testing::class,'addProduct']);

Route::post('/add_product_ajax',[testing::class,'add_product_ajax'])->name('add_product_ajax');


Route::post('/delete_product_ajax',[testing::class,'delete_product_ajax'])->name('delete_product_ajax');