<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;


use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Helper\Helpers;
use Illuminate\Support\Facades\Storage;
use App\Models\File;
// use Illuminate\Http\Request;




class Testing extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    //
    public function test1(){

        echo'ok';
    }
     public function list(){

        //        $list = DB::select("SELECT * FROM list");
        // return view('list',['list' => $list]);
        return view('list');
    }



public function change_ajax(){

        $id = $_POST['id'] ;
        $p_sta = DB::select("SELECT * FROM list where id='$id'");


    $sta = $p_sta[0]->status ;

    if($sta == 0){
         $postdata = array(
    'status' => 1,       
     );
         $response['status'] ='Completed';
    }if($sta == 1){
         $postdata = array(
    'status' => 0,       
     );
         $response['status'] ='Non-Completed';
    }

    $updated = DB::table('list')
            ->where('id', $id)
            ->update($postdata);

            
        
             echo json_encode($response);

        }

 public function t_delete($id = 0){

            // $this->prx($id) ;
    DB::table('list')->where('id', $id)->delete();
    // return redirect()->route('route.name', [$param]);
     return redirect()->to('/');
                }




public function add_task_ajax(){

        $t_name = $_POST['t_name'] ;
        $p_task = DB::select("SELECT * FROM list where name='$t_name'");

        if(!empty($p_task)){
            $response['status'] ='duplicate';
        }else{

    $postdata = array(
    'name' => $t_name,
     );

  $id =   DB::table('list')->insertGetId($postdata);
$response['status'] ='added';
}            
        
             echo json_encode($response);

        }

// =========================================================

        public function productList(){

        //        $list = DB::select("SELECT * FROM list");
        // return view('list',['list' => $list]);
        return view('productTable');
    }


 public function addproduct(){

        //        $list = DB::select("SELECT * FROM list");
        // return view('list',['list' => $list]);
        return view('addproduct');
    }


 public function add_product_ajax(Request $request){                


        


                $file = $request->file('p_img');
                $img = '' ;
                if(!empty($file)){
                    $t = count($file) ;
                    $i = 0 ;
                    
                    foreach($file as $f){

                $tt = time();

                
                $filename = $_FILES["p_img"]['name'][$i] ;
                $ext = pathinfo($filename, PATHINFO_EXTENSION);
                
                $new_name = $tt . rand() .'.'. $ext ;

                $name = time().$f->getClientOriginalName();
        //          $request->validate([
        // 'p_img' => 'required|max:2048'
        
        // 'file' => 'required|mimes:csv,txt,xlx,xls,pdf|max:2048'
        // ]);
                $f->move('storage/', $new_name);
                $i++;

                $img .= $new_name ;
                if($i < $t){ $img .= '~' ; }

            }
        }

                $p_id = $_POST['p_id'] ;
                 $p_name = $_POST['p_name'] ;
                  $p_price = $_POST['p_price'] ;
                   $p_desc = $_POST['p_desc'] ;

                   if(empty($p_id) || empty($p_name) || empty($p_price) || empty($p_desc)){
                    $response['status'] ='required';
echo json_encode($response);
                    exit;
                   }

                    if(!empty($_POST['row_id'])){
                        
                   $id = $_POST['row_id'] ;
                   if(!empty($_POST['p_old_img']) && !empty($img )){
                   $old_imgs = implode("~",$_POST['p_old_img']) ;
                   $all_img = $old_imgs .'~'.$img ;

                    }else if(empty($_POST['p_old_img']) && !empty($img )){
                        $all_img = $img ;
                    }
                    else if(!empty($_POST['p_old_img']) && empty($img )){
                        $all_img = implode("~",$_POST['p_old_img']) ;
                    }
                        
                    


                    $postdata = array(  'p_id' => $p_id,
                        'p_name' => $p_name,
                        'p_price' => $p_price,
                        'p_desc' => $p_desc,
                        'img' => $all_img, );

                    
                   $updated = DB::table('p_list')
            ->where('id', $id)
            ->update($postdata);


               }else{
                            
       
    $postdata = array(  'p_id' => $p_id,
                        'p_name' => $p_name,
                        'p_price' => $p_price,
                        'p_desc' => $p_desc,
                        'img' => $img, );

  $id =   DB::table('p_list')->insertGetId($postdata);
}

  if(!empty($id)){
    $response['status'] ='added';
}else{
    $response['status'] ='failed';
}

echo json_encode($response);

    }




 public function delete_product_ajax(){                

                    
                $id = $_POST['productId'] ;
                DB::table('p_list')->where('id', $id)->delete();
                $response['status'] ='deleted';
echo json_encode($response);
       
       }


 public function prx($text){

        echo'<pre>';
        print_r($text);
        echo'</pre>';
        exit;
    }



}
