<?php // Code within app\Helpers\Helper.php

namespace App\Helpers;

class Helper
{
    public static function shout(string $string)
    {
        return strtoupper($string);
    }

    public function prx($text){

        echo'<pre>';
        print_r($text);
        echo'</pre>';
        exit;
    }
}